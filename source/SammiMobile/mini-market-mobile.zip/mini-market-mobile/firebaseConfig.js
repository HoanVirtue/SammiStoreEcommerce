import firebase from "firebase/compat/app";
import "firebase/compat/auth";
import "firebase/compat/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyDQsShmVvnfvOLAZp4dimETR1v5UeJBn6Q",
  authDomain: "mini-market-6f6a5.firebaseapp.com",
  projectId: "mini-market-6f6a5",
  storageBucket: "mini-market-6f6a5.appspot.com",
  messagingSenderId: "103541311770",
  appId: "1:103541311770:web:60768780fd6f8ea51544a3",
  measurementId: "G-XT7PNW75NP",
};
firebase.initializeApp(firebaseConfig);

export default firebase;
