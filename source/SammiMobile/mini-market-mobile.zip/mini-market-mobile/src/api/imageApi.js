class ImageApi {
  uploadOne(file) {}
}

const imageApi = new ImageApi();

export default imageApi;
