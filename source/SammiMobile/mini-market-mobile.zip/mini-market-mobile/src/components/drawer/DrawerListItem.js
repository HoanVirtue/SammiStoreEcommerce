import React from "react";
import { View, StyleSheet } from "react-native";

const DrawerListItem = () => {
  return <View></View>;
};

const styles = StyleSheet.create({});

export default DrawerListItem;
