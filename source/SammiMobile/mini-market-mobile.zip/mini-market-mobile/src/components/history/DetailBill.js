import React from "react";
import { View, StyleSheet } from "react-native";

const DetailBill = () => {
  return <View></View>;
};

const styles = StyleSheet.create({});

export default DetailBill;
