import React from "react";
import { View, StyleSheet, Text } from "react-native";
import { Layout } from "@ui-kitten/components";

const Register = () => {
  return (
    <Layout>
      <Text>Register screen</Text>
    </Layout>
  );
};

const styles = StyleSheet.create({});

export default Register;
